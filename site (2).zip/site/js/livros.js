const livrosData = [
  {
    id: 1,
    titulo: 'O Hobbit',
    autor: 'J R R Tolkien',
    preco: 40.00,
    capa: './img/o hobbit.png',
    quantidade: 0

  },
  {
    id: 2,
    titulo: 'Senhor Dos Aneis',
    autor: 'J R R Tolkien',
    preco: 40.00,
    capa: './img/o senho dos aneis.jpg',
    quantidade: 0

  },
  {
    id: 3,
    titulo: 'O Silmarillion',
    autor: 'J R R Tolkien',
    preco: 40.00,
    capa: './img/o silmarillion.jpg',
    quantidade: 0

  },
  {
    id: 4,
    titulo: 'A Arte da Guerra',
    autor: 'Sun Tzu',
    preco: 40.00,
    capa: './img/a arte da guerra.jpg',
    quantidade: 0

  },
  {
    id: 5,
    titulo: 'O Milagre Da Manhã',
    autor: 'Elrod,Hal',
    preco: 40.00,
    capa: './img/o milagre da manha.jpg',
    quantidade: 0

  },
  {
    id: 6,
    titulo: 'Do Mil Ao Milhão',
    autor: 'Nigro,Thiago',
    preco: 40.00,
    capa: './img/do mil ao milhao.jpg',
    quantidade: 0

  },
  {
    id: 7,
    titulo: '1000 lugares para conhecer antes de morrer',
    autor: 'Patricia Schultz',
    preco: 40.00,
    capa: './img/1000 lugares para conhecer antes de morrer.jpg',
    quantidade: 0

  },
  {
    id: 8,
    titulo: 'MILLER ANESTESIA',
    autor: 'RONALD D. MILLER MD MS',
    preco: 40.00,
    capa: './img/MILLER ANESTESIA.jpg',
    quantidade: 0
  }
]

const descData = [
  {
    qtd: 2,
    desc: 0.05
  },
  {
    qtd: 3,
    desc: 0.1
  },
  {
    qtd: 4,
    desc: 0.2
  },
  {
    qtd: 5,
    desc: 0.25
  }
]

function adicionar (num) {
  let add
  let unidade = livrosData[num].quantidade
  add = livrosData[num].id
  unidade = unidade + 1
  livrosData[num].quantidade = unidade
  console.log(unidade)
  return add, unidade
}

function adicionar (num) {
  let add
  let unidade = livrosData[num].quantidade
  add = livrosData[num].id
  unidade = unidade + 1
  livrosData[num].quantidade = unidade
  console.log(unidade)
  return add, unidade
}

function Livros () {
  return `
  ${alert(livrosData[1].titulo)}
  `
}

function desconto (add, quantidade, preco, qtd, desc) {
  preco = livrosData[add].preco
  quantidade = livrosData[add].quantidade
  const total = quantidade * preco
  if (quantidade == 1) {
    return total
  }

  let data = descData[descData.length - 1]

  for (let i = 0; i < descData.length; i++) {
    if (quantidade === data.qtd) {
      data = descData[i]
      break
    }
  }

  return total - total * data.desc
}

function livroTemplate (livro) {
  return `
	  <div id="${livro.id}" class="col-3 px-1">
	    <div class="card mb-2">
	    	<img class="card-img-top" src="${livro.capa}" alt="${livro.titulo}">
	      	<div class="card-body text-body">
	        <h5 class="card-title">${livro.titulo}</h5>
	        <p class="card-text">${livro.autor}</p>
	        <p mx-auto>R$: ${livro.preco}</p>
	        <button type="button" id="r${livro.id}" class="btn btn-primary" onclick="remover(${livro.id})">Remover</button>
			
	        <button type="button" id="a${livro.id}" class="btn btn-primary" onclick="adicionar(${livro.id})")>Adicionar</button>
	        
	      </div>
	    </div>
	  </div>
`
}

function carrinhoTemplate (livro) {
  return `
	  <ul>
		<li>Título: ${livro.titulo}</li>
		<li>Autor: ${livro.autor}</li>
		<li>${livro.preco}</li>
		<li>quantidade: ${livro.quantidade}</li>
		<li>
			<i class="fas fa-minus" onclick="remover(${livro.id})"></i>
			<i class="fas fa-plus" onclick="adicionar(${livro.id})"></i>
		</li>
	  </ul>
`
}

document.getElementById('cart').innerHTML = `
	${livrosData.map(carrinhoTemplate).join('')}

`

document.getElementById('prateleira').innerHTML = `
	${livrosData.map(livroTemplate).join('')}

`
