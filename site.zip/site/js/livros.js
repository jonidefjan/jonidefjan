const livrosData = [
  {
    id: 1,
    titulo: 'O Hobbit',
    autor: 'J R R Tolkien',
    preco: 'R$: 40.00',
    capa: './img/o hobbit.png'

  },
  {
    id: 2,
    titulo: 'Senhor Dos Aneis',
    autor: 'J R R Tolkien',
    preco: 'R$: 40.00',
    capa: './img/o senho dos aneis.jpg'

  },
  {
    id: 3,
    titulo: 'O Silmarillion',
    autor: 'J R R Tolkien',
    preco: 'R$: 40.00',
    capa: './img/o silmarillion.jpg'

  },
  {
    id: 4,
    titulo: 'A Arte da Guerra',
    autor: 'Sun Tzu',
    preco: 'R$: 40.00',
    capa: './img/a arte da guerra.jpg'

  },
  {
    id: 5,
    titulo: 'O Milagre Da Manhã',
    autor: 'Elrod,Hal',
    preco: 'R$: 40.00',
    capa: './img/o milagre da manha.jpg'

  },
  {
    id: 6,
    titulo: 'Do Mil Ao Milhão',
    autor: 'Nigro,Thiago',
    preco: 'R$: 40.00',
    capa: './img/do mil ao milhao.jpg'

  },
  {
    id: 7,
    titulo: '1000 lugares para conhecer antes de morrer',
    autor: 'Patricia Schultz',
    preco: 'R$: 40.00',
    capa: './img/1000 lugares para conhecer antes de morrer.jpg'

  },
  {
    id: 8,
    titulo: 'MILLER ANESTESIA',
    autor: 'RONALD D. MILLER MD MS',
    preco: 'R$: 40.00',
    capa: './img/MILLER ANESTESIA.jpg'
  }
]

const descData = [
  {
    qtd: 2,
    desc: 0.05
  },
  {
    qtd: 3,
    desc: 0.1
  },
  {
    qtd: 4,
    desc: 0.2
  },
  {
    qtd: 5,
    desc: 0.25
  }
]

function adicionar () {
  let add
  for (var i = 0; i < livrosData.length; i++) {
    add = livrosData[i]
    console.log(add)
  }
}

function Livros () {
  return `
  ${alert(livrosData[1].titulo)}
  `
}

function desconto (quantidade, preco, qtd, desc) {
  const total = quantidade * preco
  if (quantidade == 1) {
    return total
  }

  let data = descData[descData.length - 1]

  for (let i = 0; i < descData.length; i++) {
    if (quantidade === data.qtd) {
      data = descData[i]
      break
    }
  }

  return total - total * data.desc
}

function livroTemplate (livro) {
  return `
	  <div id="${livro.id}" class="col-3 px-1">
	    <div class="card mb-2">
	    	<img class="card-img-top" src="${livro.capa}" alt="${livro.titulo}">
	      	<div class="card-body text-body">
	        <h5 class="card-title">${livro.titulo}</h5>
	        <p class="card-text">${livro.autor}</p>
	        <p mx-auto>${livro.preco}</p>
	        <button type="button" id="r${livro.id}" class="btn btn-primary" onclick="remover()">Remover</button>
			
	        <button type="button" id="a${livro.id}" class="btn btn-primary" onclick="adicionar()")>Adicionar</button>
	        
	      </div>
	    </div>
	  </div>
`
}

function carrinhoTemplate (livro) {
  return `
	  <ul>
		<li>Título: ${livro.titulo}</li>
		<li>Autor: ${livro.autor}</li>
		<li>${livro.preco}</li>
		<li>quantidade: ${livro.quantidade}</li>
		<i class="fas fa-minus" onclick="remover()"></i>
		<i class="fas fa-plus" onclick="adicionar()"></i">
	  </ul>
`
}

document.getElementById('cart').innerHTML = `
	${livrosData.map(carrinhoTemplate).join('')}

`

document.getElementById('prateleira').innerHTML = `
	${livrosData.map(livroTemplate).join('')}

`
