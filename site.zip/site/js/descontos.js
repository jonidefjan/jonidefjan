const descData = [
  {
    qtd: 2,
    desc: 0.05
  },
  {
    qtd: 3,
    desc: 0.1
  },
  {
    qtd: 4,
    desc: 0.2
  },
  {
    qtd: 5,
    desc: 0.25
  }
]
